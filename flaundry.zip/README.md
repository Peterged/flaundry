# UNFINISHED
## Note that this isn't the Laundry you're looking for.

Short Description:
A somewhat unique php MVC architecture (or maybe not).
It's similar to express's syntax
