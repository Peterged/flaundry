<?php

namespace App\controllers;

class PagesController
{
    public function index()
    {
        echo "Pages index";
    }

    public function create()
    {
        echo "Pages create";
    }

    public function store()
    {
        echo "Pages store";
    }

    public function show()
    {
        echo "Pages show";
    }

    public function edit()
    {
        echo "Pages edit";
    }

    public function update()
    {
        echo "Pages update";
    }

    public function destroy()
    {
        echo "Pages destroy";
    }
}
