<?php 
namespace App\controllers;

    class UserController  {
        public function index() {
            echo "User index";
        }

        public function create() {
            echo "User create";
        }

        public function store() {
            echo "User store";
        }

        public function show() {
            echo "User show";
        }

        public function edit() {
            echo "User edit";
        }

        public function update() {
            echo "User update";
        }

        public function destroy() {
            echo "User destroy";
        }
    }
?>