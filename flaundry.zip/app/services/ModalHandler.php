<?php 
    
class Modal {
    
}