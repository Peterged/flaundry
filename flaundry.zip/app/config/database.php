<?php

namespace App\config;
$con = new \App\Libraries\Database(\DB_USER, \DB_PASS);
